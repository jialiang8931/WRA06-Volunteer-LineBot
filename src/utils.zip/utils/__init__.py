from utils.handler_create_tables import create_relevant_tables

status_create_tables = create_relevant_tables()
