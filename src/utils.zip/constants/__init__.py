from .configuration import get_config_setting

setting = get_config_setting()
